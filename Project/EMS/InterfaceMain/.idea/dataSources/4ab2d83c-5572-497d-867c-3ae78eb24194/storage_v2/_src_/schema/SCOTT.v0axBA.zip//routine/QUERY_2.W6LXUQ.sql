create PROCEDURE Query_2 IS

    mID mother.motherID%TYPE;
    fID father.fatherID%TYPE;

    CURSOR cur_mother_id IS
        SELECT DISTINCT mother_id
        from student_archive;

BEGIN

   OPEN cur_mother_id;

   LOOP
        FETCH cur_mother_id
        INTO mID;
        EXIT

    WHEN cur_mother_id%NOTFOUND;
        SELECT father_id
        INTO fID;
        FROM student_archive
        where mother_id = mID;

        dbms_output.put_line('Mother id: ' || mID || char(10) || 'Father id: ' || fID);
    END LOOP;

    CLOSE cur_mother_id;

END;
/


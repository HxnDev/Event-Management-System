create procedure update_commission(monthly_sale NUMBER, target_sale NUMBER, emp_id NUMBER) IS

begin
if monthly_sale>target_sale then
update emp
set comm=0.25*(monthly_sale - target_sale)
where empno=emp_id;

else
update emp
set comm=50
where empno=emp_id;

end if;

end;
/

